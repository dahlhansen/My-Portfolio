import React from "react";
import ReactRoundedImage from "react-rounded-image";

function Home() {
  return <div className="text-center">
            <h1 className="text-4x1 font-bold text-blue-700">Welcome!</h1>

            <ReactRoundedImage>
              
            </ReactRoundedImage>
            
        </div>
}

export default Home;
