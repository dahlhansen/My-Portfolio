function Projects() {
    return <h1>Projects Works!</h1>;
  }
  
  export default Projects;
  